// Nick Liousas
// 7/29/2023

#include <iostream>
#include <fstream> // ifstream class
#include <string>

using namespace std;

int main() {
    ifstream inFS;
    ofstream outFS;
    string cityName; // CityName from FarenheitTemperature.txt file
    int tempFarenheit; // Farenheit temp
    double tempCelsius; // Celsius temp


    inFS.open("FarenheitTemperature.txt"); // Opening the given Farenheit file with listed Cities and Temps
    outFS.open("CelsiusTemperature.txt"); // Open the Celsius file to convert temp


    while (inFS >> cityName >> tempFarenheit) { // Using formula given - while writing new temp to the CelsiusTemperature.txt file
        tempCelsius = (tempFarenheit - 32) * 5.0 / 9.0; // Using the Fahrenheit to Celsius conversion formula 
        outFS << cityName << " " << tempCelsius << endl; // Output for Celsius temp
    }


    inFS.close();
    outFS.close();


    return 0;

}